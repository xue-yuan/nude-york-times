# nude-york-times

## Installation

### Chrome

> not sure chrome work correctly

1. Clone the repository.
2. Goto `chrome://extensions/`.
3. Turn on the developer mode.
4. Click on 'Load unpacked'.
5. Choose the project folder.

### Firefox

1. Download at [Firefox Addons](https://addons.mozilla.org/zh-TW/firefox/addon/nude-york-times/)

## Known Issue

1. Some sections will broken/not work.
2. Lazy loaded images doesn't show up.

## Future Work

1. Add lazy loaded images to placeholder.
